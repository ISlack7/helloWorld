class Main {
  public static void main(String[] args) {
    int myAge = 15;
    int myBirthday = 728;
    int todaysDate = 922;

    if(myBirthday == todaysDate)
    {
      System.out.print("I am + 15 + 1");
    }else{
      System.out.print("I am still 15");
    }
  }
}
  }
}